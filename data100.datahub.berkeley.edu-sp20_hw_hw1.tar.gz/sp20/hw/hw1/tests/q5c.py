test = {   'name': 'q5c',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               'np.isclose(no_disease_given_negative(1), '
                                               '1)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               'np.isclose(no_disease_given_negative(0), '
                                               '0.998947423819799)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
