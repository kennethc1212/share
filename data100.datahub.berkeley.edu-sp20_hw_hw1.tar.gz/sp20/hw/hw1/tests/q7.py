test = {   'name': 'q7',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> 10000 <= q7_survey <= '
                                               '9999\n'
                                               'False',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
